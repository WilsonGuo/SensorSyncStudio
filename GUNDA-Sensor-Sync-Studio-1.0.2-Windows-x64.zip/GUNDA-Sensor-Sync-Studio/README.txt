GUNDA Sensor Sync Studio 1.0.2

Run sensor_sync_studio.exe directly. No installation is required.
Connect the synchronizer before startup and select its COM port.

Supported systems: Windows 10/11 x64
